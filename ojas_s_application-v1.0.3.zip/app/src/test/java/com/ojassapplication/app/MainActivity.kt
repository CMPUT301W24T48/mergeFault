package com.ojassapplication.app

import com.ojassapplication.app.appcomponents.base.BaseActivity
import com.ojassapplication.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}